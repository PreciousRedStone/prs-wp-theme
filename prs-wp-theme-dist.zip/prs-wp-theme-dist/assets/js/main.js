(function (root, doc, $) {

  return {};

})(window, document, jQuery);